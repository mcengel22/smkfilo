<?php

namespace App\Modules\Reservation\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ReservationResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'        => $this->id,
            'code'      => $this->code,
            'startDate' => $this->start_date,
            'endDate'   => $this->end_date,
            'image' => $this->post?->media ? [
                'media_url' => $this->post->media->url,
                'media_title' => $this->post->media->title,
                'media_alt' => $this->post->media->alt,
            ] : null,
            'title' => $this->post->title,
            'slug' => $this->post->slug,
            'customer'  => $this->reservable->full_name ?? 'Harici',
            'price'     => $this->price,
            'status'    => $this->status,
            'state'     => $this->state,
            'type'     => $this->type,
        ];
    }
}
