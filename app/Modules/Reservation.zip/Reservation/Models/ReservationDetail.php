<?php

namespace App\Modules\Reservation\Models;

use Illuminate\Database\Eloquent\Model;

class ReservationDetail extends Model
{
    protected $table = 'reservation_details';

    protected $fillable = [
        'reservation_id',
        'adults',
        'children',
        'infants',
        'cleaning_fee',
        'deposit',
        'note',
    ];

    // 📎 İlişki: Bu detay bir rezervasyona ait
    public function reservation()
    {
        return $this->belongsTo(Reservation::class);
    }
}
