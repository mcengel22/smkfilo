<?php

namespace App\Modules\Reservation\Observers;

use App\Mail\NotificationMailer;
use App\Modules\Notifications\Models\Notifications;
use App\Modules\Post\Models\Post;
use App\Modules\Reservation\Models\Reservation;
use App\Modules\User\Models\User;
use App\Modules\User\Models\Guest;
use App\Services\NetGSMService;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;

class ReservationObserver
{
    protected NetGSMService $smsService;

    public function __construct(NetGSMService $smsService)
    {
        $this->smsService = $smsService;
    }

    /**
     * Yeni rezervasyon oluşturulunca tetiklenir
     */
    public function created(Reservation $model): void
    {
        $smsService = $this->smsService;

        DB::afterCommit(function () use ($model, $smsService) {
            [$name, $email, $phone] = $this->getUserInfo($model);

            $adminMsg = "Yeni Rezervasyon: Sayın $name, {$model->start_date} - {$model->end_date} arası rezervasyon oluşturdu. Kodu: {$model->code}";
            $confirmMsg = "Sayın $name,\n\nRezervasyonunuz başarıyla alınmıştır. Onay sürecindedir.\nRezervasyon Kodu: {$model->code}";

            $this->notifyAdmins($adminMsg);
            $this->notifyUser($model, $email, $phone, $confirmMsg, 'reservation_confirmation');

            $owner = Post::with('user')->find($model->post_id)?->user;
            if ($owner) {
                $ownerMsg = "İlanınıza yeni rezervasyon: $name, {$model->start_date} - {$model->end_date}\nKod: {$model->code}";
                $this->notifyUserDirect($owner->id, $owner->email, $owner->phone, $ownerMsg, 'post_reservation');
            }
        });
    }

    /**
     * Rezervasyon güncellenince (onaylandı/iptal) tetiklenir
     */
    public function updated(Reservation $model): void
    {
        $old = $model->getOriginal('status');
        $new = $model->status?->value;

        if ($old !== $new && in_array($new, ['confirmed', 'canceled'])) {
            [$name, $email, $phone] = $this->getUserInfo($model);

            $message = $new === 'confirmed'
                ? "Sayın $name, rezervasyonunuz onaylandı. Kod: {$model->code}"
                : "Sayın $name, rezervasyonunuz iptal edilmiştir.";

            $this->notifyUser($model, $email, $phone, $message, 'reservation_status_update');
        }
    }

    /**
     * Kullanıcı bilgilerini çözer (User veya Guest)
     */
    protected function getUserInfo(Reservation $model): array
    {
        $name = 'Misafir';
        $email = $phone = null;

        if ($model->reservable_type === User::class) {
            $user = User::find($model->reservable_id);
            if ($user) {
                $name = trim("$user->name $user->surname");
                $email = $user->email;
                $phone = $user->phone;
            }
        } elseif ($model->reservable_type === Guest::class) {
            $guest = Guest::find($model->reservable_id);
            if ($guest) {
                $name = trim("$guest->first_name $guest->last_name");
                $email = $guest->email;
                $phone = $guest->phone;
            }
        } elseif (is_array($model->guest)) {
            $name = trim(($model->guest['first_name'] ?? '') . ' ' . ($model->guest['last_name'] ?? ''));
            $email = $model->guest['email'] ?? null;
            $phone = $model->guest['phone'] ?? null;
        }

        return [$name ?: 'Misafir', $email, $phone];
    }

    /**
     * Super admin'lere bildirim + mail + sms
     */
    protected function notifyAdmins(string $message): void
    {
        $admins = User::where('type', 'super_admin')->get();

        if ($admins->isEmpty()) return;

        foreach ($admins as $admin) {
            Notifications::create([
                'user_id' => $admin->id,
                'type' => 'reservation',
                'message' => $message,
                'read' => false,
            ]);

            if ($admin->email) {
                Mail::to($admin->email)->send(
                    new NotificationMailer(new Notifications(['message' => $message]))
                );
            }

            if ($admin->phone) {
                $this->smsService->sendSMS($admin->phone, $message);
            }
        }
    }

    /**
     * Kullanıcıya (User veya Guest) mail + sms
     */
    protected function notifyUser(Reservation $model, ?string $email, ?string $phone, string $message, string $type): void
    {
        if ($email) {
            if ($model->reservable_type === User::class) {
                Notifications::create([
                    'user_id' => $model->reservable_id,
                    'type' => $type,
                    'message' => $message,
                    'read' => false,
                ]);
            }

            Mail::to($email)->send(
                new NotificationMailer(new Notifications(['message' => $message]))
            );
        }

        if ($phone) {
            $this->smsService->sendSMS($phone, $message);
        }
    }

    /**
     * İlan sahibine doğrudan bildirim
     */
    protected function notifyUserDirect(int $userId, ?string $email, ?string $phone, string $message, string $type): void
    {
        Notifications::create([
            'user_id' => $userId,
            'type' => $type,
            'message' => $message,
            'read' => false,
        ]);

        if ($email) {
            Mail::to($email)->send(
                new NotificationMailer(new Notifications(['message' => $message]))
            );
        }

        if ($phone) {
            $this->smsService->sendSMS($phone, $message);
        }
    }

    /**
     * Silinince yapılacak işlemler (şu an boş)
     */
    public function deleted(Reservation $model): void
    {
        // Opsiyonel: log tutmak istersen buraya yazabilirsin
    }
}
